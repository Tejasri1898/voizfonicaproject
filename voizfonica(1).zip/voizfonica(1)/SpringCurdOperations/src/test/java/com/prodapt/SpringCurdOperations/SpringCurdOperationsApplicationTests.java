package com.prodapt.SpringCurdOperations;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringCurdOperationsApplicationTests {

	@Test
	void contextLoads() {
	}

}
