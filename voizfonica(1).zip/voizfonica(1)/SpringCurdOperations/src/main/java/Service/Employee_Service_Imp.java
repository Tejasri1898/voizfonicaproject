package Service;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import DAO.Employee_DAO;
import Model.Employee;


@Service
@Transactional
public class Employee_Service_Imp implements Employee_Service {

	@Autowired
	private Employee_DAO employeedao;

	@Override
	public boolean saveEmployee(Employee employee) {
		return employeedao.saveEmployee(employee);
	}

	@Override
	public List<Employee> getEmployees() {

		return employeedao.getEmployees();
	}

	@Override
	public Employee deleteEmployee(Integer id) {
		return  employeedao.deteleEmployee(id);
	}
	
	@Override
	public Employee getEmployeeById(Integer id) {
		return  employeedao.getEmployeesById(id);
	}

	@Override
	public boolean updateStudent(Employee employee) {
		// TODO Auto-generated method stub
		return false;
	}
	

	
	
	
}


