package Service;
import java.util.List;

import Model.Employee;

public interface Employee_Service {

	
	public boolean saveEmployee(Employee employee);
	
	public List<Employee> getEmployees();
	public Employee deleteEmployee(Integer id);
	public Employee getEmployeeById(Integer id);
//	public boolean deleteStudent(Student student);
//	public List<Student> getStudentByID(Student student);
     public boolean updateStudent(Employee employee);
}

