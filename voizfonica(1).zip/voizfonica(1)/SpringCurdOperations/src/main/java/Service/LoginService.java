package Service;

import org.springframework.stereotype.Service;

@Service
public class LoginService {
	public boolean validateUser(String userId, String password) {
		return userId.equalsIgnoreCase("vamshi") && password.equalsIgnoreCase("vamshi");
	}

	public boolean validateUserDB(String userId, String password) {
		// try db connect and call dao
		if (true) {
	   return true;
		} else {
	   return false;
		}

	}
}