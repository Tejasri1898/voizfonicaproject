package Controller;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import Service.LoginService;

@Controller
@CrossOrigin
//@RequestMapping(value = "/view")
@ComponentScan
public class WebController implements WebMvcConfigurer {
	@RequestMapping("/Home") // end point URL REST API crud ( creat:POST read:GET update:PUT delete:DELETE)
	public String jspCheck() {
		return "Home";
	}
	@RequestMapping("/PrePaid") // end point URL REST API crud ( creat:POST read:GET update:PUT delete:DELETE)
	public String Paid() {
		return "PrePaid";
	}
	@RequestMapping("/help")
	public String help() {
		return "help";
	}


	@RequestMapping("/Login")
	public String form() {
		return "Login";
	}
	@RequestMapping("/register")
	public String Reg() {
		return "register";
	}
	

	@Autowired
	LoginService service;

	@RequestMapping(value = "/login", method = RequestMethod.GET)
	public String showLoginPage(ModelMap model) {
		return "Login";
	}
	

	@RequestMapping(value = "/login", method = RequestMethod.POST)
	public String showWelcomePage(ModelMap model, @RequestParam String name, @RequestParam String password,
			@RequestParam String role) {
		System.out.println("The Role is " + role);
		boolean isValiduser = service.validateUser(name, password);

		if (!isValiduser) {
			model.put("errorMessage", "Invalid Credentials");
			return "Login";
		}
		model.put("name", name);
		model.put("password", password);

		return "Welcome";
	}
}