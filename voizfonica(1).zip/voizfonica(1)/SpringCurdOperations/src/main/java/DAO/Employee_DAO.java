package DAO;
import java.util.List;

import Model.Employee;


public interface Employee_DAO {

	public boolean saveEmployee(Employee employee);

	public List<Employee> getEmployees();
	public Employee deteleEmployee(Integer id);
	public Employee getEmployeesById(Integer id);
	

	
	
}